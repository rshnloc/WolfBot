interface JQuery {
    datetimepicker: (options: any) => JQuery;
}