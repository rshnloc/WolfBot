$(document).ready(function() {
    // add your custom code here...
    console.log( "ready!" );
});