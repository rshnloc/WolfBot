
// TODO add routes here based on a simple Router class that listens for URL fragment changes