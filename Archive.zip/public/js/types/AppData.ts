
export interface AppData {
    lang: string;
    locale: string;
    tvReady: boolean;
    siteUrl: string;
}