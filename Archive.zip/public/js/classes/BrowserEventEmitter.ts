/**
 * A simple event emitter for web browsers.
 * Its API is modeled on the EventEmitter class of NodeJS.
 * Also see https://github.com/Olical/EventEmitter and https://github.com/asyncly/EventEmitter2
 * we use EventEmitter2 for now
 */
/*
export class BrowserEventEmitter {
    constructor() {
    }
}
*/